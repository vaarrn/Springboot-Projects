package com.spring.docker.services;

import java.util.List;

import com.spring.docker.entity.Student;

public interface StudentService {

	List<Student> getAllStudents();

	Student getStudentById(Long id);

	Student updateStudent(Student student);

	Student saveStudent(Student student);
	
	void deleteStudent(Student student);

}
