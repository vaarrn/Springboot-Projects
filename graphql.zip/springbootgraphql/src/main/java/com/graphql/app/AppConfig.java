package com.graphql.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import graphql.kickstart.servlet.apollo.ApolloScalars;
import graphql.schema.GraphQLScalarType;

@Configuration
public class AppConfig implements WebMvcConfigurer {

	@Bean
	public GraphQLScalarType uploadScalarDefine()
	{
		return ApolloScalars.Upload;
	}

}
