package com.graphql.app.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.graphql.app.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long>{

}
