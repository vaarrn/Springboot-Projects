package com.graphql.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootgraphqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootgraphqlApplication.class, args);
	}

}
