package com.graphql.app.constants;

public class Constants {
	
	public static final String FILEURL="http://localhost:8000/students/jsonresponse";
	
	public static final String ATTACHMENT="attachment; filename=students.json";
	
	public static final String DIRECTORY= "c:\\temp";
	
	public static final String FILENAME="students.json";
	
	public static final String SUCCESS="Success";
	
	public static final String FILESUCCESS="File Uploaded Successfully";
}
