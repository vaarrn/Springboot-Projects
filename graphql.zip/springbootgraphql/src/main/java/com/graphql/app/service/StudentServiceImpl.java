package com.graphql.app.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.graphql.app.entity.Student;
import com.graphql.app.exception.StudentNotFoundException;
import com.graphql.app.repo.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Autowired
	private RestTemplate restTemplate;

	@Override
	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	@Override
	public Student getStudent(Long id) {
		return studentRepository.findById(id)
				.orElseThrow(() -> new StudentNotFoundException("Student does not exist with ID " + id));
	}

	@Override
	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public Student updateStudent(Long id, String firstName, String lastName, String location) {
		Student student = getStudent(id);
		if (firstName != null) {
			student.setFirstName(firstName);
		}
		if (lastName != null) {
			student.setLastName(lastName);
		}
		if (location != null) {
			student.setLocation(location);
		}
		return saveStudent(student);
	}

	@Override
	public void deleteStudent(Long id) {
		Student student = new Student();
		student = studentRepository.findById(id)
				.orElseThrow(() -> new StudentNotFoundException("Student does not exist with ID " + id));
		studentRepository.delete(student);
	}

	@Override
	public Student createStudent(String firstName, String lastName, String location) {
		Student student = new Student(firstName, lastName, location);
		return studentRepository.save(student);
	}

	@Override
	public HttpStatus download(String url, String localDirectory, String filename) throws IOException {
		ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
		if (response.getStatusCode() == HttpStatus.OK) {
			try (FileWriter writer = new FileWriter(new File(localDirectory, filename))) {
				writer.write(response.getBody());
			}
			return HttpStatus.valueOf(response.getStatusCode().value());
		} else {
			throw new IOException("Failed to download file");
		}
	}

}
