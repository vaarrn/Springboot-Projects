package com.graphql.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.graphql.app.entity.Student;
import com.graphql.app.repo.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	@Override
	public Student getStudent(Long id) {
		return studentRepository.findById(id).get();
	}

	@Override
	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public Student updateStudent(Long id, String firstName, String lastName, String location) {
		Student student = getStudent(id);
		if (student == null) {
			return null;
		}
		if (firstName != null) {
			student.setFirstName(firstName);
		}
		if (lastName != null) {
			student.setLastName(lastName);
		}
		if (location != null) {
			student.setLocation(location);
		}
		return saveStudent(student);
	}

	@Override
	public void deleteStudent(Long id) {
		studentRepository.deleteById(id);
	}

	@Override
	public Student createStudent(String firstName, String lastName, String location) {
		Student student=new Student(firstName, lastName, location);
		return studentRepository.save(student);
	}

}
