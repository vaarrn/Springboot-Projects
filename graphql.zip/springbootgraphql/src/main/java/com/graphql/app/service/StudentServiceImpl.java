package com.graphql.app.service;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.graphql.app.entity.Student;
import com.graphql.app.repo.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> getAllStudents() {
		return studentRepository.findAll();
	}

	@Override
	public Student getStudent(Long id) {
		return studentRepository.findById(id).get();
	}

	@Override
	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public Student updateStudent(Long id, String firstName, String lastName, String location) {
		Student student = getStudent(id);
		if (student == null) {
			return null;
		}
		if (firstName != null) {
			student.setFirstName(firstName);
		}
		if (lastName != null) {
			student.setLastName(lastName);
		}
		if (location != null) {
			student.setLocation(location);
		}
		return saveStudent(student);
	}

	@Override
	public void deleteStudent(Long id) {
		studentRepository.deleteById(id);
	}

	@Override
	public void addStudentsFromJson(MultipartFile file) throws IOException {
		ObjectMapper objectMapper = new ObjectMapper();
		List<Student> students = objectMapper.readValue(file.getInputStream(), new TypeReference<List<Student>>() {
		});
		studentRepository.saveAll(students);
	}

}
