package com.graphql.app.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.graphql.app.entity.Student;

public interface StudentService {

	List<Student> getAllStudents();

	Student getStudent(Long id);

	Student saveStudent(Student student);

	Student updateStudent(Long id, String firstName, String lastName, String location);

	void deleteStudent(Long id);
	
	void addStudentsFromJson(MultipartFile file) throws IOException;
	
	
}
