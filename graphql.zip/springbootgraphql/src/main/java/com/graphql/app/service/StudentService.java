package com.graphql.app.service;

import java.io.IOException;
import java.util.List;

import org.springframework.http.HttpStatusCode;

import com.graphql.app.entity.Student;

public interface StudentService {

	List<Student> getAllStudents();

	Student getStudent(Long id);

	Student saveStudent(Student student);
	
	Student createStudent(String firstName, String lastName, String location);


	Student updateStudent(Long id, String firstName, String lastName, String location);

	void deleteStudent(Long id);
	
	HttpStatusCode download(String url, String localDirectory, String filename) throws IOException;

}
