package com.graphql.app.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.graphql.app.entity.Student;
import com.graphql.app.entity.StudentData;
import com.graphql.app.service.StudentServiceImpl;

@RestController
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentServiceImpl studentService;

	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
		byte[] bytes = file.getBytes();
		ObjectMapper objectMapper = new ObjectMapper();
		List<StudentData> studentDataList = objectMapper.readValue(bytes, new TypeReference<List<StudentData>>() {
		});

		for (StudentData studentData : studentDataList) {
			Student student = new Student(studentData.getFirstName(), studentData.getLastName(),
					studentData.getLocation());
			studentService.createStudent(student.getFirstName(), student.getLastName(), student.getLocation());
		}

		return "File uploaded successfully.";
	}
}
