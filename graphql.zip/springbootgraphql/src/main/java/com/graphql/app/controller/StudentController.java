package com.graphql.app.controller;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.graphql.app.constants.Constants;
import com.graphql.app.entity.Student;
import com.graphql.app.entity.StudentData;
import com.graphql.app.service.StudentServiceImpl;

@RestController
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentServiceImpl studentService;
	
	Logger logger= LoggerFactory.getLogger(StudentController.class);

	@PostMapping("/upload")
	public String uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
		byte[] bytes = file.getBytes();
		ObjectMapper objectMapper = new ObjectMapper();
		List<StudentData> studentDataList = objectMapper.readValue(bytes, new TypeReference<List<StudentData>>() {
		});

		for (StudentData studentData : studentDataList) {
			Student student = new Student(studentData.getFirstName(), studentData.getLastName(),
					studentData.getLocation());
			studentService.createStudent(student.getFirstName(), student.getLastName(), student.getLocation());
		}

		return Constants.FILESUCCESS;
	}

	@GetMapping(value = "/json")
	public List<Student> downloadStudents() {
		List<Student> students = studentService.getAllStudents();
		return students;

	}

	@GetMapping(value = "/download")
	public String download() throws IOException {
		String url = Constants.FILEURL;
		String localDirectory = Constants.DIRECTORY;
		String filename = Constants.FILENAME;
		HttpStatusCode status = studentService.download(url, localDirectory, filename);
		if (status == HttpStatus.OK) {
			logger.info("File downloaded successfully.");
		}
		return Constants.SUCCESS;

	}

}
