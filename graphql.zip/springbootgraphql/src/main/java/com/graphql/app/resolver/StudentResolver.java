package com.graphql.app.resolver;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.graphql.app.entity.Student;
import com.graphql.app.service.StudentServiceImpl;

import graphql.kickstart.tools.GraphQLMutationResolver;
import graphql.kickstart.tools.GraphQLQueryResolver;

@Component
public class StudentResolver implements GraphQLQueryResolver, GraphQLMutationResolver {

	@Autowired
	private StudentServiceImpl studentService;

	public List<Student> getAllStudents() {
		return studentService.getAllStudents();
	}

	public Student getStudent(Long id) {
		return studentService.getStudent(id);
	}

	public Student createStudent(String firstName, String lastname, String location) {
		Student student = new Student(firstName, lastname, location);
		return studentService.saveStudent(student);
	}

	public Student updateStudent(Long id, String firstName, String lastName, String location) {
		return studentService.updateStudent(id, firstName, lastName, location);
	}

	public String deleteStudent(Long id) {
		studentService.deleteStudent(id);
		return "Student with ID " + id + " has been deleted.";
	}

	public String addStudentsFromJson(MultipartFile file) throws IOException {
		studentService.addStudentsFromJson(file);
		return "Students added from JSON file";
	}

}
