package com.graphql.app.resolver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.graphql.app.entity.Student;
import com.graphql.app.service.StudentServiceImpl;

import graphql.kickstart.tools.GraphQLMutationResolver;
import graphql.kickstart.tools.GraphQLQueryResolver;





@Component
public class StudentResolver implements GraphQLQueryResolver,GraphQLMutationResolver{
	
	@Autowired
	private StudentServiceImpl studentService;
	
	public List<Student> getAllStudents()
	{
		return studentService.getAllStudents();
	}
	
	public Student getStudent(Long id)
	{
		return studentService.getStudent(id);
	}
	
	public Student createStudent(String firstName, String lastname, String location) {
        Student student = new Student(firstName, lastname, location);
        return studentService.saveStudent(student);
    }
	public Student updateStudent(Long id, String firstName, String lastName, String location) {
		return studentService.updateStudent(id, firstName, lastName, location);
	}

	public String deleteStudent(Long id) {
		studentService.deleteStudent(id);
		return "Student with ID " + id + " has been deleted.";
	}

	public String uploadFile(@RequestParam("file") MultipartFile file) throws Exception {
		// Parse the uploaded JSON file
		ObjectMapper mapper = new ObjectMapper();
		List<Student> students = mapper.readValue(file.getInputStream(), new TypeReference<List<Student>>() {});

		// Process the data from the JSON file
		for (Student student : students) {
			studentService.saveStudent(student);
		}

		return "File uploaded successfully";
	}



}
