package com.graphql.app.resolver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.graphql.app.entity.Student;
import com.graphql.app.repo.StudentRepository;

import graphql.kickstart.tools.GraphQLQueryResolver;

@Component
public class StudentResolver implements GraphQLQueryResolver {
	
	@Autowired
	private StudentRepository studentRepository;
	
	public List<Student> getAllStudents()
	{
		return studentRepository.findAll();
	}
}
