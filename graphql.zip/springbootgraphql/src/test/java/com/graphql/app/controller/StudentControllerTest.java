package com.graphql.app.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.graphql.app.constants.Constants;
import com.graphql.app.entity.Student;
import com.graphql.app.entity.StudentData;
import com.graphql.app.service.StudentServiceImpl;

class StudentControllerTest {

	@Mock
	private StudentServiceImpl studentService;

	@InjectMocks
	private StudentController studentController;

	@SuppressWarnings("deprecation")
	@BeforeEach
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testUploadFile() throws Exception {
		List<StudentData> studentDataList = new ArrayList<>();
		studentDataList.add(new StudentData("John", "Doe", "New York"));
		studentDataList.add(new StudentData("Jane", "Doe", "Los Angeles"));

		ObjectMapper objectMapper = new ObjectMapper();
		String jsonString = objectMapper.writeValueAsString(studentDataList);

		String response = studentController.uploadFile(new MockMultipartFile("file", jsonString.getBytes()));

		verify(studentService).createStudent("John", "Doe", "New York");
		verify(studentService).createStudent("Jane", "Doe", "Los Angeles");

		assertEquals(Constants.FILESUCCESS, response);
	}

	@Test
	public void testDownloadStudents() {
		List<Student> students = new ArrayList<>();
		students.add(new Student("John", "Doe", "New York"));
		students.add(new Student("Jane", "Doe", "Los Angeles"));
		when(studentService.getAllStudents()).thenReturn(students);
		List<Student> result = studentController.downloadStudents();
		assertEquals(students, result);
	}

	@Test
	public void testDownload() throws Exception {
		when(studentService.download(Constants.FILEURL, Constants.DIRECTORY, Constants.FILENAME))
				.thenReturn(HttpStatus.OK);
		String result = studentController.download();
		verify(studentService).download(Constants.FILEURL, Constants.DIRECTORY, Constants.FILENAME);
		assertEquals(Constants.SUCCESS, result);
	}

}
