package com.graphql.app.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.graphql.app.constants.Constants;
import com.graphql.app.entity.Student;
import com.graphql.app.exception.StudentNotFoundException;
import com.graphql.app.repo.StudentRepository;

class StudentServiceImplTest {

	@InjectMocks
	private StudentServiceImpl studentService;

	@Mock
	private StudentRepository studentRepository;

	@Mock
	private RestTemplate restTemplate;

	private final Student student = new Student("John", "Doe", "New York");
	private final List<Student> students = Arrays.asList(student);

	private final String url = "http://example.com/data.txt";
	private final String localDirectory = Constants.DIRECTORY;
	private final String filename = "data.txt";

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetAllStudents() {
		doReturn(students).when(studentRepository).findAll();

		List<Student> result = studentService.getAllStudents();

		assertThat(result).hasSameElementsAs(students);
	}

	@Test
	void testGetStudent() {
		doReturn(Optional.of(student)).when(studentRepository).findById(1L);

		Student result = studentService.getStudent(1L);

		assertThat(result).isEqualTo(student);
	}

	@Test
	void testGetStudent_NotFound() {
		doReturn(Optional.empty()).when(studentRepository).findById(1L);

		try {
			studentService.getStudent(1L);
		} catch (Exception ex) {
			assertThat(ex).isInstanceOf(StudentNotFoundException.class).hasMessage("Student does not exist with ID 1");
		}
	}

	@Test
	void testSaveStudent() {
		doReturn(student).when(studentRepository).save(any(Student.class));

		Student result = studentService.saveStudent(student);

		assertThat(result).isEqualTo(student);
	}

	@Test
	void testUpdateStudent() {
		doReturn(Optional.of(student)).when(studentRepository).findById(1L);
		doReturn(student).when(studentRepository).save(any(Student.class));

		Student result = studentService.updateStudent(1L, "John", "Smith", "Los Angeles");

		assertThat(result).isEqualTo(student);
		assertThat(student.getFirstName()).isEqualTo("John");
		assertThat(student.getLastName()).isEqualTo("Smith");
		assertThat(student.getLocation()).isEqualTo("Los Angeles");
	}

	@Test
	void testDeleteStudent() {
		doReturn(Optional.of(student)).when(studentRepository).findById(1L);
		doNothing().when(studentRepository).delete(student);

		studentService.deleteStudent(1L);
	}

	@Test
	void testDeleteStudent_NotFound() {
		doReturn(Optional.empty()).when(studentRepository).findById(1L);

		try {
			studentService.deleteStudent(1L);
		} catch (Exception ex) {
			assertThat(ex).isInstanceOf(StudentNotFoundException.class).hasMessage("Student does not exist with ID 1");
		}
	}

	@Test
	public void testCreateStudent() {
		String firstName = "John";
		String lastName = "Doe";
		String location = "New York";
		Student expectedStudent = new Student(firstName, lastName, location);
		when(studentRepository.save(any(Student.class))).thenReturn(expectedStudent);

		Student actualStudent = studentService.createStudent(firstName, lastName, location);

		assertEquals(expectedStudent, actualStudent);
		verify(studentRepository, times(1)).save(any(Student.class));
	}

	@Test
	public void testDownloadSuccess() throws IOException {
		// mock successful response from RestTemplate
		String responseBody = "Some data to download";
		ResponseEntity<String> response = new ResponseEntity<>(responseBody, HttpStatus.OK);
		when(restTemplate.getForEntity(url, String.class)).thenReturn(response);

		// call download method
		HttpStatus status = studentService.download(url, localDirectory, filename);

		// verify file is created and status is OK
		assertEquals(HttpStatus.OK, status);
		File file = new File(localDirectory, filename);
		assertEquals(true, file.exists());
		assertEquals(responseBody, new String(java.nio.file.Files.readAllBytes(file.toPath())));
		file.delete();
	}

	@Test
	public void testDownloadFailure() {
	    // mock unsuccessful response from RestTemplate
	    when(restTemplate.getForEntity(url, String.class)).thenReturn(new ResponseEntity<>(HttpStatus.NOT_FOUND));

	    // call download method, should throw IOException
	    Throwable exception = assertThrows(IOException.class, () -> studentService.download(url, localDirectory, filename));
	    assertEquals("Failed to download file", exception.getMessage());
	}


}
