package com.graphql.app.resolver;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.graphql.app.entity.Student;
import com.graphql.app.service.StudentServiceImpl;

public class StudentResolverTest {

	@Mock
	private StudentServiceImpl studentService;

	private StudentResolver studentResolver;

	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		studentResolver = new StudentResolver();
		studentResolver.studentService = studentService;
	}

	@Test
	public void testGetAllStudents() {
		List<Student> students = new ArrayList<>();
		students.add(new Student(1L, "John", "Doe", "New York"));
		students.add(new Student(2L, "Jane", "Doe", "London"));
		when(studentService.getAllStudents()).thenReturn(students);
		assertEquals(students, studentResolver.getAllStudents());
	}

	@Test
	public void testGetStudent() {
		Student student = new Student(1L, "John", "Doe", "New York");
		when(studentService.getStudent(1L)).thenReturn(student);
		assertEquals(student, studentResolver.getStudent(1L));
	}

	@Test
	public void testCreateStudent() {
		Student student = studentResolver.createStudent("John", "Doe", "New York");
		when(studentService.saveStudent(student)).thenReturn(student);
		assertEquals(student, studentResolver.createStudent("John", "Doe", "New York"));
	}

	@Test
	public void testUpdateStudent() {
		Student student = new Student(1L, "John", "Doe", "New York");
		when(studentService.updateStudent(1L, "John", "Doe", "London")).thenReturn(student);
		assertEquals(student, studentResolver.updateStudent(1L, "John", "Doe", "London"));
	}

	@Test
	void testDeleteStudent() {
		Long id = 1L;
		String result = studentResolver.deleteStudent(id);
		verify(studentService, times(1)).deleteStudent(id);
		assertEquals("Student with ID " + id + " has been deleted.", result);
	}

}
