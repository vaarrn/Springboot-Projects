package com.project.demo.service;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.project.demo.entity.JobStatus;
import com.project.demo.repo.JobRepository;

@SpringBootTest
public class DownloadServiceTest {
    
    @MockBean
    private JobRepository jobRepository;
    
    private DownloadService downloadService;
    
    @BeforeEach
    public void setup() {
        downloadService = new DownloadService();
        downloadService.restTemplate = mock(RestTemplate.class);
        downloadService.jobRepository = jobRepository;
    }
    
    @SuppressWarnings("unchecked")
	@Test
    public void testDownload_success() throws IOException {
        ResponseEntity<byte[]> response = new ResponseEntity<>("test".getBytes(), HttpStatus.OK);
        when(downloadService.restTemplate.getForEntity(any(String.class), any(Class.class))).thenReturn(response);
        downloadService.download();
        verify(jobRepository).save(any(JobStatus.class));
    }
    
    @SuppressWarnings("unchecked")
	@Test
    public void testDownload_failure() throws IOException {
        ResponseEntity<byte[]> response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        when(downloadService.restTemplate.getForEntity(any(String.class), any(Class.class))).thenReturn(response);
        downloadService.download();
        verify(jobRepository).save(any(JobStatus.class));
    }
    
    @Test
    public void testUpdateStatus() {
        downloadService.updateStatus("Success");
        verify(jobRepository).save(any(JobStatus.class));
    }
    
    
}


