package com.project.demo.scheduler;

import java.io.IOException;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.project.demo.service.DownloadService;

@Component
public class CopyScheduler {
  
  private final DownloadService downloadService;
  private final JavaMailSender mailSender;
  
  public CopyScheduler(DownloadService downloadService, JavaMailSender mailSender) {
    this.downloadService = downloadService;
    this.mailSender = mailSender;
  }
  
  @Scheduled(fixedRate = 20000) 
  public void copyFile() {
    try {
      downloadService.download();
      System.out.println("Job Done Successfully!");
    } catch (IOException e) {
      sendFailureEmail(e);
    }
  }
  
  public void sendFailureEmail(Exception e) {
    SimpleMailMessage message = new SimpleMailMessage();
    message.setSubject("Job Failed");
    message.setText("The copy job failed with the following error:\n\n" + e.getMessage()+
    					"\n\nPlease try again after resolving the errors\n\nCheers Tech Team!");
    message.setTo("dummydummy170700@gmail.com");
    message.setFrom("dummydummy170700@gmail.com");
    mailSender.send(message);
    System.out.println("Job Failed Mail Has been sent with corresponding errors !");
  }
}
