package com.project.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.demo.entity.JobStatus;

public interface JobRepository extends JpaRepository<JobStatus, Long>{

}
