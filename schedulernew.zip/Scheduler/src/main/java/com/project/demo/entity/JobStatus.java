package com.project.demo.entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class JobStatus {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	Long id;
		
	String fileName;
	
	String status;
	
	Date dowloadDate;
	
	public JobStatus()
	{
		
	}

	public JobStatus(String fileName, String status, Date dowloadDate) {
		super();
		this.fileName = fileName;
		this.status = status;
		this.dowloadDate = dowloadDate;
	}

	public Long getId() {
		return id;
	}

	public String getFileName() {
		return fileName;
	}

	public String getStatus() {
		return status;
	}

	public Date getDowloadDate() {
		return dowloadDate;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setDowloadDate(Date dowloadDate) {
		this.dowloadDate = dowloadDate;
	}
	
	
	
	
	

}
