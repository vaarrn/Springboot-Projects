package com.project.demo.service;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.demo.entity.JobStatus;
import com.project.demo.repo.JobRepository;

@Service
public class DownloadService {
	
	@Autowired
	private JobRepository jobRepository;
	private final String fileUrl = "https://workupload.com/start/zNtEUqDL";
	private final String localDirectory = "C:\\Testing\\destination";
	private final String filename = "remote-textfile.txt";

	public void download() throws IOException {
		
		URL url = new URL(fileUrl);
		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setRequestMethod("GET");
		int responseCode = connection.getResponseCode();

		if (responseCode == HttpURLConnection.HTTP_OK) {
			try (BufferedInputStream in = new BufferedInputStream(connection.getInputStream());

				FileOutputStream out = new FileOutputStream(new File(localDirectory, filename))) {
				byte[] buffer = new byte[1024];
				int bytesRead;
				while ((bytesRead = in.read(buffer)) != -1) {
					out.write(buffer, 0, bytesRead);

				}
			}
			updateStatus("Sucess");
		} else
			updateStatus("Failed");
		
	}

	private void updateStatus(String success) {
		
		JobStatus jobStatus = new JobStatus();
		jobStatus.setStatus(success);
		jobStatus.setDowloadDate(new Date());
		jobStatus.setFileName(filename);
		jobRepository.save(jobStatus);

	}
}
