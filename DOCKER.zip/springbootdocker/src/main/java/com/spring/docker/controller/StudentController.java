package com.spring.docker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.docker.entity.Student;
import com.spring.docker.services.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/getAllStudents")
	public List<Student> getAllStudents() {
		return studentService.getAllStudents();
	}

	@PostMapping("/createStudent")
	public Student addStudent(@RequestBody Student student) {
		return studentService.saveStudent(student);
	}

	@GetMapping("/getStudent/{id}")
	public Student getStudentById(@PathVariable Long id) {
		return studentService.getStudentById(id);

	}

	@PutMapping("/updateStudent/{id}")
	public Student updateStudent(@RequestBody Student student, @PathVariable Long id) {

		Student existingStudent = studentService.getStudentById(id);
		existingStudent.setFirstName(student.getFirstName());
		existingStudent.setLastName(student.getLastName());
		existingStudent.setLocation(student.getLocation());
		return studentService.saveStudent(existingStudent);

	}

	@DeleteMapping("/deleteStudent/{id}")
	public ResponseEntity<Student> deleteStudent(@PathVariable Long id) {
		Student existingStudent = studentService.getStudentById(id);
		studentService.deleteStudent(existingStudent);
		return ResponseEntity.ok().build();
	}

}
