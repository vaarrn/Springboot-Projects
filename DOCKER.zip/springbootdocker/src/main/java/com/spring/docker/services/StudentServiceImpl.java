package com.spring.docker.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.docker.entity.Student;
import com.spring.docker.exception.StudentNotFoundException;
import com.spring.docker.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository repository;

	@Override
	public List<Student> getAllStudents() {
		return repository.findAll();
	}

	@Override
	public Student getStudentById(Long id) {
		return repository.findById(id).orElseThrow(()-> new StudentNotFoundException("Student not found with Id "+id));
	}

	@Override
	public Student updateStudent(Student student) {
		return repository.save(student);
	}

	@Override
	public Student saveStudent(Student student) {
		return repository.save(student);
	}

	@Override
	public void deleteStudent(Student student) {
		repository.delete(student);
	}

}
