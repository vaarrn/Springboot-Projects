package com.spring.docker.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.spring.docker.entity.Student;
import com.spring.docker.exception.StudentNotFoundException;
import com.spring.docker.repository.StudentRepository;

class StudentServiceImplTest {

	@Mock
	private StudentRepository repository;

	@InjectMocks
	private StudentServiceImpl service;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetAllStudents() {
		List<Student> students = new ArrayList<>();
		Student student1 = new Student("Varun", "Ajith", "Kochi");
		student1.setId(1L);
		students.add(student1);
		Student student2 = new Student("Arjun", "Ajith", "Trivandrum");
		student2.setId(2L);
		students.add(student2);

		when(repository.findAll()).thenReturn(students);

		List<Student> actual = service.getAllStudents();

		assertEquals(students, actual);
	}

	@Test
	void testGetStudentById() {
		Long id = 1L;
		Student student = new Student("Varun", "Ajith", "Kochi");
		student.setId(id);

		when(repository.findById(id)).thenReturn(Optional.of(student));

		Student actual = service.getStudentById(id);

		assertEquals(student, actual);
	}

	@Test
	void testGetStudentByIdNotFound() {
		Long id = 1L;

		when(repository.findById(id)).thenReturn(Optional.empty());

		assertThrows(StudentNotFoundException.class, () -> {
			service.getStudentById(id);
		});
	}

	@Test
	void testUpdateStudent() {
		Long id = 1L;
		Student student = new Student("Varun", "Ajith", "Kochi");
		student.setId(id);

		when(repository.save(student)).thenReturn(student);

		Student actual = service.updateStudent(student);

		assertEquals(student, actual);
	}

	@Test
	void testSaveStudent() {
		Long id = 1L;
		Student student = new Student("Varun", "Ajith", "Kochi");
		Student savedStudent = new Student("Varun", "Ajith", "Kochi");
		savedStudent.setId(id);

		when(repository.save(student)).thenReturn(savedStudent);

		Student actual = service.saveStudent(student);

		assertEquals(savedStudent, actual);
	}

	@Test
	void testDeleteStudent() {
		Long id = 1L;
		Student student = new Student("Varun", "Ajith", "Kochi");
		student.setId(id);

		doNothing().when(repository).delete(student);

		service.deleteStudent(student);

		verify(repository, times(1)).delete(student);
	}

}