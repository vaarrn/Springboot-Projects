package com.spring.docker.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.spring.docker.entity.Student;
import com.spring.docker.services.StudentService;

public class StudentControllerTest {

	@Mock
	private StudentService studentService;

	@InjectMocks
	private StudentController studentController;

	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllStudents() {
		List<Student> students = new ArrayList<>();
		students.add(new Student("Varun", "Ajith", "Kochi"));
		students.add(new Student("Sabrina", "John", "Banglore"));
		Mockito.when(studentService.getAllStudents()).thenReturn(students);
		List<Student> result = studentController.getAllStudents();
		assertEquals(students, result);
	}

	@Test
	void testGetStudentById() {

		Student mockStudent = new Student();
		mockStudent.setId(1L);
		mockStudent.setFirstName("Varun");
		mockStudent.setLastName("Ajith");
		mockStudent.setLocation("Kochi");

		when(studentService.getStudentById(1L)).thenReturn(mockStudent);

		Student response = studentController.getStudentById(1L);

		assertEquals(mockStudent, response);
	}

	@Test
	public void testDeleteStudent() {
		Long studentId = 1L;
		Student existingStudent = new Student("Varun", "Ajith", "Kochi");
		existingStudent.setId(studentId);
		Mockito.when(studentService.getStudentById(studentId)).thenReturn(existingStudent);

		ResponseEntity<Student> response = studentController.deleteStudent(studentId);

		Mockito.verify(studentService, Mockito.times(1)).deleteStudent(existingStudent);
		assertEquals(HttpStatus.OK, response.getStatusCode());
	}

	@Test
	public void testAddStudent() {
		Student newStudent = new Student("Varun", "Ajith", "Kochi");
		Mockito.when(studentService.saveStudent(newStudent)).thenReturn(newStudent);

		Student savedStudent = studentController.addStudent(newStudent);

		Mockito.verify(studentService, Mockito.times(1)).saveStudent(newStudent);
		assertEquals(newStudent.getId(), savedStudent.getId());
		assertEquals(newStudent.getFirstName(), savedStudent.getFirstName());
		assertEquals(newStudent.getLastName(), savedStudent.getLastName());
		assertEquals(newStudent.getLocation(), savedStudent.getLocation());
	}

	@Test
	public void testUpdateStudent() {

		Long studentId = 1L;
		Student existingStudent = new Student("Varun", "Ajith", "Kochi");
		existingStudent.setId(studentId);
		Student updatedStudent = new Student("Arjun", "Ajith", "Trivandrum");
		Mockito.when(studentService.getStudentById(studentId)).thenReturn(existingStudent);
		Mockito.when(studentService.saveStudent(existingStudent)).thenReturn(existingStudent);

		Student savedStudent = studentController.updateStudent(updatedStudent, studentId);

		Mockito.verify(studentService, Mockito.times(1)).getStudentById(studentId);
		Mockito.verify(studentService, Mockito.times(1)).saveStudent(existingStudent);
		assertEquals(existingStudent.getId(), savedStudent.getId());
		assertEquals(updatedStudent.getFirstName(), savedStudent.getFirstName());
		assertEquals(updatedStudent.getLastName(), savedStudent.getLastName());
		assertEquals(updatedStudent.getLocation(), savedStudent.getLocation());
	}

}
