package com.project.demo.service;

import java.io.IOException;

public interface Download {
	
	void download() throws IOException;
	void updateStatus(String status);
	void sendFailureEmail(Exception e);
	
}
