package com.project.demo.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.project.demo.entity.JobStatus;
import com.project.demo.repo.JobRepository;

@Service
public class DownloadImpl implements Download {

	@Autowired
	JobRepository jobRepository;

	String fileUrl = "https://workupload.com/start/zNtEUqDL";

	String localDirectory = "D:\\source";

	String filename = "remote-textfile1.txt";

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	JavaMailSender mailSender;

	@Override
	public void download() throws FileNotFoundException, IOException {

		ResponseEntity<byte[]> response = restTemplate.getForEntity(fileUrl, byte[].class);
		if (response.getStatusCode() == HttpStatus.OK) {
			try (FileOutputStream out = new FileOutputStream(new File(localDirectory, filename))) {
				out.write(response.getBody());
			}
			updateStatus("Success");
		} else {
			throw new IOException("Failed to download file");
		}
	}

	@Override
	public void updateStatus(String status) {
		JobStatus jobStatus = new JobStatus();
		jobStatus.setFileName(filename);
		jobStatus.setStatus(status);
		jobStatus.setDownloadDate(new Date());
		jobRepository.save(jobStatus);
	}

	@Override
	public void sendFailureEmail(Exception e) {
		SimpleMailMessage message = new SimpleMailMessage();
		message.setSubject("Job Failed");
		message.setText("The copy job failed with the following error:\n\n" + e.getMessage()
				+ "\n\nPlease try again after resolving the errors\n\nCheers Tech Team!");
		message.setTo("dummydummy170700@gmail.com");
		message.setFrom("dummydummy170700@gmail.com");
		mailSender.send(message);
		System.out.println("Job Failed Mail Has been sent with corresponding errors !");
	}

}
