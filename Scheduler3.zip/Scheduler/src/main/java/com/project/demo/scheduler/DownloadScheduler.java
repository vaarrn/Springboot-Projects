package com.project.demo.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.project.demo.service.DownloadService;

@Component
public class DownloadScheduler {

	@Autowired
	private DownloadService downloadService;

	@Scheduled(fixedRate = 60000) // 1 hour
	public void downloadFile() {
		try {
			downloadService.download();
			System.out.println("Job Done Successfully!");
		} catch (Exception e) {
			downloadService.sendFailureEmail(e);
			downloadService.updateStatus(e.toString());
		}
	}

	
}
