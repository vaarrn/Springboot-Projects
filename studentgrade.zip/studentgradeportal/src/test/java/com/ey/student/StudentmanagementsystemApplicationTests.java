package com.ey.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentmanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
