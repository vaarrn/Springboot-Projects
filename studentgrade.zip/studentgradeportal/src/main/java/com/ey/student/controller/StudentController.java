package com.ey.student.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ey.student.entity.Student;
import com.ey.student.exception.IdNotFoundException;
import com.ey.student.service.StudentService;

@Controller
public class StudentController extends Exception {
	
	

	private static final long serialVersionUID = 1L;
	
	@Autowired
	private StudentService studentService;

	@GetMapping("/students")
	public String listStudents(Model model) {
		model.addAttribute("students", studentService.getAllStudents());
		return "students";

	}
	
	@GetMapping("/students/view/{id}")
	public String singleStudent(@PathVariable Long id,Model model) throws IdNotFoundException
	{	
		try {
		Optional<Student> student = studentService.getStudentByIdd(id);
		model.addAttribute("students",student.get());
		return "single_view";
		}
		catch(Exception e)
		{
			throw new IdNotFoundException("Record not found with Id :"+id);
		}
	}
	
	@GetMapping("/students/view")
	public String studentreq(@RequestParam Long id,@RequestParam(name="name",required = false) String firstName,Model model) throws IdNotFoundException
	{	
		try {    
		model.addAttribute("students", studentService.getStudentById(id));
		return "single_view";
		}catch(Exception e)
		{
			throw new IdNotFoundException("Record not found with Id :"+id);
		}
	}
	
	@GetMapping("/students/new")
	public String createStudentForm(Model model) {
		Student student = new Student();
		model.addAttribute("student", student);
		return "create_student";
	}

	@PostMapping("/students")
	public String saveStudent(@ModelAttribute("student") Student student) {
		studentService.saveStudent(student);
		return "redirect:/students";
	}

	@GetMapping("/students/edit/{id}")
	public String editStudentForm(@PathVariable Long id, Model model) throws IdNotFoundException {
		try {
		model.addAttribute("student", studentService.getStudentById(id));
		return "edit_student";
		}catch(Exception e)
		{
			throw new IdNotFoundException("Record not found with Id :"+id);
		}
	}

	@PostMapping("/students/{id}")
	public String updateStudent(@PathVariable Long id, @ModelAttribute("student") Student student,
			Model model) {
		
		Student existingStudent=studentService.getStudentById(id);
		
		existingStudent.setId(student.getId());
		existingStudent.setFirstName(student.getFirstName());
		existingStudent.setLastName(student.getLastName());
		existingStudent.setGrade(student.getGrade());
		
		studentService.saveStudent(existingStudent);
		
		return "redirect:/students";
	}
	
	@GetMapping("/students/delete/{id}")
	public String deleteStudent(@PathVariable Long id)
	{	
		try {
		studentService.deleteStudentById(id);
		return "redirect:/students";
		}catch(Exception e)
		{
			throw new IdNotFoundException("Record not found with ID :"+id);
		}
	}
}
