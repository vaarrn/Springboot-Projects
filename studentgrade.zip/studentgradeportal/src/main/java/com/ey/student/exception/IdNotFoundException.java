package com.ey.student.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value=HttpStatus.NOT_FOUND)
public class IdNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	String msg;
	public IdNotFoundException(String msg)
	{
		super();
		this.msg=msg;
		
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	

}
