package com.ey.student.exception;


import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class GlobalException
{
	
	@ExceptionHandler(IdNotFoundException.class)
	public ModelAndView processCustomException(IdNotFoundException e) 
	{
		ModelAndView m=new ModelAndView("/customError");
		m.addObject("msg",e.getMsg());
		return m;
	}
	
	@ExceptionHandler(Exception.class)
	public ModelAndView Exception(Exception e) 
	{
		ModelAndView m=new ModelAndView("/globalError");
		m.addObject("msg",e.getMessage());
		return m;
	}
	
	
}
