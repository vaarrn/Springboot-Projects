package com.project.demo.service;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Service;


@Service
public class CopyService{
	
	private final String sourceDirectory = "D:\\source";
	  private final String targetDirectory = "D:\\destination";
	  
	  public void copy() throws IOException {
	    FileUtils.copyFile(new File(sourceDirectory, "test.txt"), new File(targetDirectory, "test1.txt"));
	  }

}
