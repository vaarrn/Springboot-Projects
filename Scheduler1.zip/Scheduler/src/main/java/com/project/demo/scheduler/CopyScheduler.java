package com.project.demo.scheduler;

import java.io.IOException;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.project.demo.service.CopyService;

@Component
public class CopyScheduler {
  
  private final CopyService copyService;
  private final JavaMailSender mailSender;
  
  public CopyScheduler(CopyService copyService, JavaMailSender mailSender) {
    this.copyService = copyService;
    this.mailSender = mailSender;
  }
  
  @Scheduled(fixedRate = 60000) // 1 hour
  public void copyFile() {
    try {
      copyService.copy();
      System.out.println("Updated");
    } catch (IOException e) {
      sendFailureEmail(e);
    }
  }
  
  private void sendFailureEmail(Exception e) {
    SimpleMailMessage message = new SimpleMailMessage();
    message.setSubject("Copy Failed");
    message.setText("The copy job failed with the following error:\n\n" + e.getMessage());
    message.setTo("varunajith00@gmail.com");
    message.setFrom("dummydummy170700@gmail.com");
    mailSender.send(message);
    System.out.println("mailsend");
  }
}
